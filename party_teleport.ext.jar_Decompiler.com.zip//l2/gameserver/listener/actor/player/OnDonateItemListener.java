package l2.gameserver.listener.actor.player;

import l2.gameserver.listener.GameListener;

public interface OnDonateItemListener extends GameListener {
   void onDonateItem(int var1, int var2, long var3);
}
