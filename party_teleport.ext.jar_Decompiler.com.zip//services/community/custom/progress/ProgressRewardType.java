package services.community.custom.progress;

public enum ProgressRewardType {
   ITEM,
   PREMIUM,
   HERO,
   NOBLE;
}
