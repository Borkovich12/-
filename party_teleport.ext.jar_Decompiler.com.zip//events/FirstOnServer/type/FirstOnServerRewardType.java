package events.FirstOnServer.type;

public enum FirstOnServerRewardType {
   ITEM,
   PREMIUM,
   HERO;
}
